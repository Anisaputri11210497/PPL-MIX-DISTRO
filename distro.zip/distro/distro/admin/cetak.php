<?php
session_start();

include 'functions.php';


$getKodePesanan = $_GET['kode_pesanan'];

?>

<!DOCTYPE html>
<html lang="en">
<!-- HEAD -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="../img/logo.png">
    <title>MIX Distro</title>
    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Rubik:400,500,700" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <!-- Slick -->
    <link type="text/css" rel="stylesheet" href="../css/slick.css" />
    <link type="text/css" rel="stylesheet" href="../css/slick-theme.css" />
    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="../css/nouislider.min.css" />
    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="../css/style.css" />
    <!-- Sweetalert -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Fontawesome Icon -->
    <script src="https://kit.fontawesome.com/348c676099.js" crossorigin="anonymous"></script>
</head>
<!-- /HEAD -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@500&display=swap');

    * {
        font-size: 0.9rem;
        font-family: 'Open Sans', sans-serif;
    }
</style>

<body>

    <div style="margin: 10px;">

        <center>
            <h3>MIX Distro</h3>
            <br>
            <!-- <p>Jl. Brig Jend. Hasan Basri Jl. Kayu Tangi 2 Jalur 3 No.77, Pangeran, Kec. Banjarmasin Utara, Kota Banjarmasin, Kalimantan Selatan 70124 <br>087861919270</p> -->
        </center>
        <div class="col">
            <div class="order-summary">
                <?php mysqli_query($conn, "SET sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''))");
                $pesanan = mysqli_query($conn, "SELECT * FROM pesanan WHERE status != 'Menunggu Pembayaran' AND kode_pesanan = '$getKodePesanan' GROUP BY kode_pesanan");
                ?>
                <?php error_reporting(0); ?>
                <?php foreach ($pesanan as $data) : ?>
                    <div class="my-2 ">

                        <div style="border-bottom: 2px dotted black;">
                            <?php if (isset($_GET['nama'])) : ?>
                                <p>Nama Pelanggan : <?= $_GET['nama']; ?></p>
                            <?php endif; ?>
                            <?php if (isset($data['waktu'])) : ?>
                                <p style="font-size: 0.8rem;">Tanggal: <?= date('d F, Y. H:i:s', strtotime($data['waktu'])); ?></p>

                                <p style="font-size: 0.8rem;">Kode Pesanan: <?= $getKodePesanan; ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="order-col">
                            <div><strong>PRODUCT</strong></div>
                            <div><strong>SUBTOTAL</strong></div>
                        </div>
                        <?php $total_harga = 0; ?>
                        <?php $total_diskon = 0; ?>
                        <div class="order-products">
                            <?php $kode_pesanan = $data['kode_pesanan']; ?>
                            <?php $detail_pesanan = mysqli_query($conn, "SELECT * FROM pesanan WHERE status != 'Menunggu Pembayaran' AND kode_pesanan = '$kode_pesanan' "); ?>
                            <?php foreach ($detail_pesanan as $detail) : ?>
                                <?php $kode = $detail['kode_pesanan']; ?>
                                <div class="order-col">
                                    <div>
                                        <small>
                                            <?php $idp = $detail['id_produk']; ?>
                                            <?php $produk = query("SELECT * FROM produk WHERE id = $idp")[0]; ?>
                                            <?= $produk['nama']; ?> &nbsp;
                                            X <?= $detail['jumlah']; ?>
                                        </small>
                                    </div>
                                    <div>
                                        <small>
                                            <?php $harga_fix = $detail['harga'] * $detail['jumlah']; ?>
                                            <span>Rp<?= number_format($harga_fix, 0, ',', '.'); ?></span>
                                        </small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            <?php if ($detail['id_kode_promo'] != NULL) : ?>
                                <div class="order-col">
                                    <div class="text-success fw-bold">Diskon Kode Promo</div>
                                    <?php
                                    $id_kode_promo = $detail['id_kode_promo'];
                                    $kode_promo = query("SELECT * FROM kode_promo WHERE id = $id_kode_promo")[0];
                                    $diskon_promo = $kode_promo['jumlah_promo'];

                                    ?>
                                    <div class="text-success fw-bold">
                                        <strong><?= $diskon_promo; ?>%</strong>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="order-col">
                                <div class="text-success fw-bold">Total Belanja</div>
                                <?php
                                $total = query("SELECT SUM(jumlah * harga) as biaya FROM pesanan WHERE  kode_pesanan = '$kode' AND status != 'Menunggu Pembayaran'")[0];
                                $total_diskon_promo = ($total['biaya'] * $diskon_promo) / 100;
                                if (!isset($total['biaya'])) {
                                    $total['biaya'] = 0;
                                }
                                ?>
                                <?php if ($detail['id_kode_promo'] != NULL) : ?>
                                    <div class="text-success fw-bold">
                                        <?php $totalFix = $total['biaya'] - $total_diskon_promo; ?>
                                        <strong>Rp<?= number_format($totalFix, 0, ',', '.'); ?></strong>
                                    </div>
                                <?php else : ?>
                                    <div class="text-success fw-bold">
                                        <strong>Rp<?= number_format($total['biaya'], 0, ',', '.'); ?></strong>
                                    </div>
                                <?php endif; ?>

                            </div>

                            <?php if (isset($_GET['jumlah_bayar'])) : ?>
                                <div class="order-col">
                                    <div class="text-success fw-bold">Jumlah Bayar</div>
                                    <div class="text-success fw-bold">
                                        <strong><?= $_GET['jumlah_bayar']; ?></strong>
                                    </div>
                                </div>

                                <div class="order-col">
                                    <div class="text-success fw-bold">Jumlah Kembali</div>
                                    <div class="text-success fw-bold">
                                        <strong><?= $_GET['jumlah_kembali']; ?></strong>
                                    </div>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>


    <script>
        window.print();
    </script>

</body>

</html>