<?php
// Koneksi ke database dan query data pesanan

// Gantikan dengan kode untuk mengakses basis data dan menjalankan query sesuai kebutuhan
// Misalnya, menggunakan mysqli atau PDO untuk mengakses MySQL

$host = 'localhost';
$db   = 'distro';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];
$pdo = new PDO($dsn, $user, $pass, $options);

$stmt = $pdo->prepare('SELECT waktu, harga FROM pesanan WHERE validasi = "Telah Divalidasi"');
$stmt->execute();
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Format data menjadi array dengan format yang diterima oleh Highcharts.js
$grafikData = [];
foreach ($data as $row) {
    $grafikData[] = [
        strtotime($row['waktu']) * 1000, // Konversi waktu menjadi milidetik UNIX
        floatval($row['harga'])
    ];
}

header('Content-Type: application/json');
echo json_encode($grafikData);
