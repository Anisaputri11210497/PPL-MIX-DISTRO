<?php
session_start();
include 'functions.php';

if (!isset($_SESSION["super_userxxx"])) {
  echo "<script>
    window.location.href='login.php';
  </script>";
  exit;
}


$zona_waktu = time() + (60 * 60 * 8);
$tanggal_sekarang = gmdate('d', $zona_waktu);

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <?php include 'link.php'; ?>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <style>
    th,
    td {
      text-align: center !important;
    }
  </style>
</head>

<body>

  <?php if (isset($_GET['welcome'])) : ?>

    <?php if ($_GET['welcome'] = "true") : ?>
      <script>
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true
        })

        Toast.fire({
          icon: 'success',
          title: 'Selamat Datang!'
        })
      </script>

    <?php endif; ?>
  <?php endif; ?>


  <!-- ======== sidebar-nav start =========== -->
  <?php include 'sidebar.php'; ?>
  <!-- ======== sidebar-nav end =========== -->

  <!-- ======== main-wrapper start =========== -->
  <main class="main-wrapper">
    <!-- ========== header start ========== -->
    <header class="header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-5 col-md-5 col-6">
            <div class="header-left d-flex align-items-center">
              <div class="menu-toggle-btn mr-20">
                <button id="menu-toggle" class="main-btn primary-btn btn-hover">
                  <i class="lni lni-chevron-left me-2"></i> Menu
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- ========== header end ========== -->

    <!-- ========== section start ========== -->
    <section class="section">
      <div class="container-fluid">
        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
          <div class="row align-items-center">
            <div class="col-md-6">
              <div class="title mb-30">
                <h2>MIX Distro Dashboard</h2>
              </div>
            </div>
            <!-- end col -->
            <div class="col-md-6">
              <div class="breadcrumb-wrapper mb-30">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                      <a href="#0">MIX Distro</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                      Dashboard
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <!-- end col -->
          </div>
          <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->
        <div class="row">
          <div class="col-xl-6 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
              <div class="icon purple">
                <i class="lni lni-cart-full"></i>
              </div>
              <div class="content">
                <h6 class="mb-10">Total Penjualan</h6>
                <?php $px = query("SELECT SUM(jumlah) as total FROM pesanan WHERE validasi IS NOT NULL")[0]; ?>
                <?php if ($px['total'] == NULL) {
                  $px['total'] = 0;
                } ?>
                <h3 class="text-bold mb-10"><?= $px['total']; ?></h3>
              </div>
            </div>
            <!-- End Icon Cart -->
          </div>
          <!-- End Col -->
          <div class="col-xl-6 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
              <div class="icon success">
                <i class="lni lni-dollar"></i>
              </div>
              <div class="content">
                <?php $px = query("SELECT SUM(jumlah * harga) as pendapatan FROM pesanan WHERE status IS NOT NULL")[0]; ?>
                <h6 class="mb-10">Total Pemasukan</h6>
                <?php if ($px['pendapatan'] == NULL) {
                  $px['pendapatan'] = 0;
                } ?>
                <h3 class="text-bold mb-10">Rp<?= number_format($px['pendapatan'], 0, ',', '.'); ?></h3>
              </div>
            </div>
            <!-- End Icon Cart -->
          </div>
        </div>

        <div id="container"></div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
          $(document).ready(function() {
            $.getJSON("get_data.php", function(data) {
              Highcharts.chart('container', {
                chart: {
                  type: 'spline'
                },
                title: {
                  text: 'Grafik Pendapatan 10 Hari Terakhir'
                },
                xAxis: {
                  type: 'datetime',
                  dateTimeLabelFormats: {
                    day: '%e %b, %Y'
                  },
                  title: {
                    text: 'Tanggal'
                  }
                },
                yAxis: {
                  title: {
                    text: 'Pendapatan'
                  }
                },
                tooltip: {
                  formatter: function() {
                    var date = Highcharts.dateFormat('%e %b, %Y', new Date(this.x));
                    var formatter = new Intl.NumberFormat('id-ID', {
                      style: 'currency',
                      currency: 'IDR',
                      maximumFractionDigits: 0
                    });
                    var formattedAmount = formatter.format(this.y);
                    return '<span style="font-size: 10px">' + date + '</span><br/>' +
                      '<span style="color:' + this.color + '">\u25CF</span> ' + this.series.name + ': ' + formattedAmount;
                  }
                },
                plotOptions: {
                  series: {
                    marker: {
                      enabled: false
                    }
                  }
                },
                series: [{
                  name: 'Pendapatan',
                  data: data
                }]
              });
            });
          });
        </script>
      </div>
      <!-- end container -->
    </section>
    <!-- ========== section end ========== -->



    <!-- ========== footer start =========== -->
    <footer class="footer">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 order-last order-md-first">
            <div class="copyright text-center text-md-start">
              <p class="text-sm">
                Designed and Developed by
                <a rel="nofollow" target="_blank">
                  Admin
                </a>
              </p>
            </div>
          </div>
          <!-- end col-->
          <div class="col-md-6">
            <div class="
                  terms
                  d-flex
                  justify-content-center justify-content-md-end
                ">
              <a href="#0" class="text-sm">Term & Conditions</a>
              <a href="#0" class="text-sm ml-15">Privacy & Policy</a>
            </div>
          </div>
        </div>
        <!-- end row -->
      </div>
      <!-- end container -->
    </footer>
    <!-- ========== footer end =========== -->
  </main>
  <!-- ======== main-wrapper end =========== -->

  <!-- ========= All Javascript files linkup ======== -->
  <script src="assets/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/Chart.min.js"></script>
  <script src="assets/js/dynamic-pie-chart.js"></script>
  <script src="assets/js/moment.min.js"></script>
  <script src="assets/js/fullcalendar.js"></script>
  <script src="assets/js/jvectormap.min.js"></script>
  <script src="assets/js/world-merc.js"></script>
  <script src="assets/js/polyfill.js"></script>
  <script src="assets/js/main.js"></script>


</body>

</html>