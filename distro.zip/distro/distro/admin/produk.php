<?php
session_start();
include 'functions.php';

// Jika form disubmit
if (isset($_POST['submit'])) {
    // Ambil data dari form
    $id_supplier = mysqli_real_escape_string($conn, $_POST['id_supplier']);
    $id_kategori = mysqli_real_escape_string($conn, $_POST['id_kategori']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    $diskon = mysqli_real_escape_string($conn, $_POST['diskon']);
    $stock = mysqli_real_escape_string($conn, $_POST['stock']);

    // Upload foto
    $foto = $_FILES['foto'];
    $foto_name = uniqid() . '.' . pathinfo($foto['name'], PATHINFO_EXTENSION);
    $foto_path = '../foto/' . $foto_name;
    move_uploaded_file($foto['tmp_name'], $foto_path);

    // Simpan data ke database
    $query = "INSERT INTO produk (id_supplier, id_kategori, nama, deskripsi, harga, diskon, stock, foto) VALUES ('$id_supplier', '$id_kategori', '$nama', '$deskripsi', '$harga', '$diskon', '$stock', '$foto_name')";
    if (mysqli_query($conn, $query)) {
        $script = "
            Swal.fire({
                icon: 'success',
                title: 'Data Berhasil Ditambahkan!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    } else {
        $script = "
            Swal.fire({
                icon: 'error',
                title: 'Data Gagal Ditambahkan!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    }
}

if (isset($_POST['edit'])) {
    // Ambil data dari form
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $id_supplier = mysqli_real_escape_string($conn, $_POST['id_supplier']);
    $id_kategori = mysqli_real_escape_string($conn, $_POST['id_kategori']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    $diskon = mysqli_real_escape_string($conn, $_POST['diskon']);
    $stock = mysqli_real_escape_string($conn, $_POST['stock']);

    // Upload foto jika ada perubahan
    if ($_FILES['foto']['size'] > 0) {
        $foto = $_FILES['foto'];
        $foto_name = uniqid() . '.' . pathinfo($foto['name'], PATHINFO_EXTENSION);
        $foto_path = '../foto/' . $foto_name;
        move_uploaded_file($foto['tmp_name'], $foto_path);
        $foto_query = ", foto = '$foto_name'";
    } else {
        $foto_query = "";
    }

    // Simpan data ke database
    $query = "UPDATE produk SET id_supplier = '$id_supplier', id_kategori = '$id_kategori', nama = '$nama', deskripsi = '$deskripsi', harga = '$harga', diskon = '$diskon', stock = '$stock' $foto_query WHERE id = '$id'";

    if (mysqli_query($conn, $query)) {
        $script = "
            Swal.fire({
                icon: 'success',
                title: 'Data Berhasil di Edit!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    } else {
        $script = "
            Swal.fire({
                icon: 'error',
                title: 'Data Gagal Di-Edit!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    }
}

if (isset($_POST['hapus'])) {
    // Ambil data dari form
    $id = mysqli_real_escape_string($conn, $_POST['id']);

    $query = "DELETE FROM produk WHERE id = '$id'";
    if (mysqli_query($conn, $query)) {
        $script = "
            Swal.fire({
                icon: 'success',
                title: 'Data Berhasil Dihapus!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    } else {
        $script = "
            Swal.fire({
                icon: 'error',
                title: 'Data Gagal Di-Hapus!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    }
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'link.php'; ?>
    <style>
        th,
        td {
            text-align: center !important;
            max-width: 100px;
        }
    </style>
    <script>
        $(document).ready(function() {

            $("#form").hide();

            $("#btn-show").click(function() {
                $("#form").show();
            })

            $("#btn-hide").click(function() {
                $("#form").hide();
            })

        });
    </script>
</head>

<body>


    <!-- ======== sidebar-nav start =========== -->
    <?php include 'sidebar.php'; ?>
    <!-- ======== sidebar-nav end =========== -->

    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">
        <!-- ========== header start ========== -->
        <header class="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-6">
                        <div class="header-left d-flex align-items-center">
                            <div class="menu-toggle-btn mr-20">
                                <button id="menu-toggle" class="main-btn primary-btn btn-hover">
                                    <i class="lni lni-chevron-left me-2"></i> Menu
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- ========== header end ========== -->

        <!-- ========== section start ========== -->
        <section class="section">
            <div class="container-fluid">
                <!-- ========== title-wrapper start ========== -->
                <div class="title-wrapper pt-30">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="title mb-30">
                                <h2>Pengelolaan Data Produk</h2>

                            </div>
                        </div>
                        <!-- end col -->
                        <div class="col-md-6">
                            <div class="breadcrumb-wrapper mb-30">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="#0">MIX Distro</a>
                                        </li>
                                        <li class="breadcrumb-item active" aria-current="page">
                                            Produk
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- ========== title-wrapper end ========== -->
                <a id="btn-show" class="btn btn-info text-white mb-3"><i class="fas fa-plus-square"></i> Tambah Data</a>


                <div class="form-elements-wrapper">
                    <div class="row">
                        <div class="col">
                            <!-- input style start -->
                            <form id="form" action="" method="post" enctype="multipart/form-data">
                                <div class="card-style mb-30">
                                    <p align="right">
                                        <a href="#" id="btn-hide" class="btn btn-close"></a>
                                    </p>
                                    <div class="input-style-1">
                                        <label>Nama</label>
                                        <input type="text" name="nama" required />
                                    </div>
                                    <div class="input-style-1">
                                        <label>Deskripsi</label>
                                        <input type="text" name="deskripsi" required />
                                    </div>
                                    <div class="input-style-1">
                                        <label>Harga</label>
                                        <input type="text" name="harga" required />
                                    </div>
                                    <div class="input-style-1">
                                        <label>Diskon</label>
                                        <input type="text" name="diskon" required />
                                    </div>
                                    <div class="input-style-1">
                                        <label>Stock</label>
                                        <input type="text" name="stock" required />
                                    </div>
                                    <div class="input-style-1">
                                        <label>Foto</label>
                                        <input type="file" name="foto" required />
                                    </div>
                                    <div class="input-style-1">
                                        <label>Kategori</label>
                                        <select class="form-control" name="id_kategori" required>
                                            <?php
                                            $kategori_query = "SELECT * FROM kategori";
                                            $kategori_result = mysqli_query($conn, $kategori_query);
                                            while ($kategori = mysqli_fetch_assoc($kategori_result)) {
                                                echo "<option value='" . $kategori['id'] . "'>" . $kategori['nama_kategori'] . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="input-style-1">
                                        <label>Supplier</label>
                                        <select class="form-control" name="id_supplier" required>
                                            <?php
                                            $supplier_query = "SELECT * FROM supplier";
                                            $supplier_result = mysqli_query($conn, $supplier_query);
                                            while ($supplier = mysqli_fetch_assoc($supplier_result)) {
                                                echo "<option value='" . $supplier['id'] . "'>" . $supplier['nama'] . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <button type="submit" name="submit" class="btn primary-btn btn-hover w-100 text-center">Tambah</button>
                                </div>
                            </form>


                        </div>
                        <!-- end card -->
                        <!-- ======= input style end ======= -->



                    </div>
                    <!-- end col -->
                </div>



                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Data Produk</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="dataX" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama</th>
                                        <th>Deskripsi</th>
                                        <th>Harga</th>
                                        <th>Diskon</th>
                                        <th>Stock</th>
                                        <th>Foto</th>
                                        <th>Supplier</th>
                                        <th>Kategori</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = "SELECT produk.*, supplier.nama AS nama_supplier, kategori.nama_kategori AS nama_kategori FROM produk JOIN supplier ON produk.id_supplier = supplier.id JOIN kategori ON produk.id_kategori = kategori.id";
                                    $result = mysqli_query($conn, $query);
                                    $i = 1;
                                    while ($data = mysqli_fetch_assoc($result)) :
                                    ?>
                                        <tr>
                                            <td><?= $i; ?></td>
                                            <td><?= htmlspecialchars($data['nama']); ?></td>
                                            <td><?= htmlspecialchars($data['deskripsi']); ?></td>
                                            <td>Rp<?= htmlspecialchars(number_format($data['harga'], 0, ',', '.')); ?></td>
                                            <td><?= htmlspecialchars($data['diskon']); ?> %</td>
                                            <td><?= htmlspecialchars($data['stock']); ?></td>
                                            <td><img src="../foto/<?= htmlspecialchars($data['foto']); ?>" alt="Foto Produk" width="100"></td>
                                            <td><?= htmlspecialchars($data['nama_supplier']); ?></td>
                                            <td><?= htmlspecialchars($data['nama_kategori']); ?></td>
                                            <td>
                                                <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?= $data['id']; ?>">Edit</a>
                                                <br><br>
                                                <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#hapusModal<?= $data['id']; ?>">Hapus</a>
                                            </td>
                                        </tr>
                                        <!-- Modal Edit Produk -->
                                        <div class="modal fade" id="editModal<?= $data['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="editModalLabel">Edit Data</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="" method="POST" enctype="multipart/form-data">
                                                            <input type="hidden" name="id" value="<?= $data['id']; ?>">
                                                            <div class="form-group mb-3">
                                                                <label for="nama">Nama</label>
                                                                <input type="text" class="form-control" id="nama" name="nama" value="<?= $data['nama']; ?>" required>
                                                            </div>
                                                            <div class="form-group mb-3">
                                                                <label for="deskripsi">Deskripsi</label>
                                                                <input type="text" class="form-control" id="deskripsi" name="deskripsi" value="<?= $data['deskripsi']; ?>" required>
                                                            </div>
                                                            <div class="form-group mb-3">
                                                                <label for="harga">Harga</label>
                                                                <input type="text" class="form-control" id="harga" name="harga" value="<?= $data['harga']; ?>" required>
                                                            </div>
                                                            <div class="form-group mb-3">
                                                                <label for="diskon">Diskon</label>
                                                                <input type="text" class="form-control" id="diskon" name="diskon" value="<?= $data['diskon']; ?>" required>
                                                            </div>
                                                            <div class="form-group mb-3">
                                                                <label for="stock">Stock</label>
                                                                <input type="text" class="form-control" id="stock" name="stock" value="<?= $data['stock']; ?>" required>
                                                            </div>
                                                            <div class="form-group mb-3">
                                                                <label for="foto">Foto</label>
                                                                <input type="file" class="form-control" id="foto" name="foto">
                                                            </div>
                                                            <div class="form-group mb-3">
                                                                <label for="id_kategori">Kategori</label>
                                                                <?php
                                                                $id_kategori = $data['id_kategori'];
                                                                $k = query("SELECT * FROM kategori WHERE id = $id_kategori")[0];
                                                                ?>
                                                                <select class="form-control" name="id_kategori" required>
                                                                    <option value="<?= $data['id_kategori'] ?>"><?= $k['nama_kategori']; ?></option>
                                                                    <?php $kategori = mysqli_query($conn, "SELECT * FROM kategori"); ?>
                                                                    <?php foreach ($kategori as $ka) : ?>
                                                                        <option value="<?= $ka['id'] ?>"><?= $ka['nama_kategori']; ?></option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </div>
                                                            <div class="form-group mb-3">
                                                                <label for="id_supplier">Supplier</label>
                                                                <?php
                                                                $id_supplier = $data['id_supplier'];
                                                                $s = query("SELECT * FROM supplier WHERE id = $id_supplier")[0];
                                                                ?>
                                                                <select class="form-control" name="id_supplier" cl required>
                                                                    <option value="<?= $data['id_supplier'] ?>"><?= $s['nama']; ?></option>
                                                                    <?php $supplier = mysqli_query($conn, "SELECT * FROM supplier"); ?>
                                                                    <?php foreach ($supplier as $su) : ?>
                                                                        <option value="<?= $su['id'] ?>"><?= $su['nama']; ?></option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </div>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                        <button type="submit" name="edit" class="btn btn-primary">Simpan</button>
                                                    </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Modal Hapus Produk -->
                                        <div class="modal fade" id="hapusModal<?= $data['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="hapusModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="hapusModalLabel">Hapus Data</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Apakah Anda yakin ingin menghapus data dengan ID Produk: <?= $data['id']; ?>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <form action="" method="post">
                                                            <input type="hidden" name="id" value="<?= $data['id'] ?>">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" name="hapus" class="btn btn-danger">Hapus</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php $i++; ?>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>

            </div>
            <!-- end container -->
        </section>
        <!-- ========== section end ========== -->

        <!-- ========== footer start =========== -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 order-last order-md-first">
                        <div class="copyright text-center text-md-start">
                            <p class="text-sm">
                                Designed and Developed by
                                <a href="https://plainadmin.com" rel="nofollow" target="_blank">
                                    PlainAdmin
                                </a>
                            </p>
                        </div>
                    </div>
                    <!-- end col-->
                    <div class="col-md-6">
                        <div class="
                  terms
                  d-flex
                  justify-content-center justify-content-md-end
                ">
                            <a href="#0" class="text-sm">Term & Conditions</a>
                            <a href="#0" class="text-sm ml-15">Privacy & Policy</a>
                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </footer>
        <!-- ========== footer end =========== -->
    </main>
    <!-- ======== main-wrapper end =========== -->

    <!-- ========= All Javascript files linkup ======== -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/Chart.min.js"></script>
    <script src="assets/js/dynamic-pie-chart.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/fullcalendar.js"></script>
    <script src="assets/js/jvectormap.min.js"></script>
    <script src="assets/js/world-merc.js"></script>
    <script src="assets/js/polyfill.js"></script>
    <script src="assets/js/main.js"></script>

    <script src="ajax/index2.js"></script>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="js/demo/datatables-demo.js"></script>


    <script>
        <?php if (isset($script)) {
            echo $script;
        } ?>
    </script>

</body>

</html>