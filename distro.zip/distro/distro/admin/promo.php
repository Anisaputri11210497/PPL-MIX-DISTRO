<?php
session_start();
include 'functions.php';


// Jika form disubmit
if (isset($_POST['submit'])) {
    // Ambil data dari form
    $kode = mysqli_real_escape_string($conn, $_POST['kode']);
    $masa_berlaku = mysqli_real_escape_string($conn, $_POST['masa_berlaku']);
    $jumlah_promo = mysqli_real_escape_string($conn, $_POST['jumlah_promo']);

    // Cek apakah kode sudah ada dalam database
    $checkQuery = "SELECT * FROM kode_promo WHERE kode = '$kode'";
    $checkResult = mysqli_query($conn, $checkQuery);
    if (mysqli_num_rows($checkResult) > 0) {
        $script = "
            Swal.fire({
                icon: 'error',
                title: 'Kode sudah ada!',
                text: 'Kode promo harus unik',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    } else {
        // Simpan data ke database
        $query = "INSERT INTO kode_promo (kode, masa_berlaku, jumlah_promo) VALUES ('$kode', '$masa_berlaku', '$jumlah_promo')";
        if (mysqli_query($conn, $query)) {
            $script = "
                Swal.fire({
                    icon: 'success',
                    title: 'Data Berhasil Ditambahkan!',
                    timer: 3000,
                    timerProgressBar: true,
                    showConfirmButton: false
                });
            ";
        } else {
            $script = "
                Swal.fire({
                    icon: 'error',
                    title: 'Data Gagal Ditambahkan!',
                    timer: 3000,
                    timerProgressBar: true,
                    showConfirmButton: false
                });
            ";
        }
    }
}

if (isset($_POST['edit'])) {
    // Ambil data dari form
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $kode = mysqli_real_escape_string($conn, $_POST['kode']);
    $masa_berlaku = mysqli_real_escape_string($conn, $_POST['masa_berlaku']);
    $jumlah_promo = mysqli_real_escape_string($conn, $_POST['jumlah_promo']);

    // Cek apakah kode sudah ada dalam database (kecuali untuk data dengan ID yang sedang diedit)
    $checkQuery = "SELECT * FROM kode_promo WHERE kode = '$kode' AND id != '$id'";
    $checkResult = mysqli_query($conn, $checkQuery);
    if (mysqli_num_rows($checkResult) > 0) {
        $script = "
            Swal.fire({
                icon: 'error',
                title: 'Kode sudah ada!',
                text: 'Kode promo harus unik',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    } else {
        // Simpan data ke database
        $query = "UPDATE kode_promo SET kode = '$kode', masa_berlaku = '$masa_berlaku', jumlah_promo = '$jumlah_promo' WHERE id = '$id'";

        if (mysqli_query($conn, $query)) {
            $script = "
                Swal.fire({
                    icon: 'success',
                    title: 'Data Berhasil di Edit!',
                    timer: 3000,
                    timerProgressBar: true,
                    showConfirmButton: false
                });
            ";
        } else {
            $script = "
                Swal.fire({
                    icon: 'error',
                    title: 'Data Gagal Di-Edit!',
                    timer: 3000,
                    timerProgressBar: true,
                    showConfirmButton: false
                });
            ";
        }
    }
}

if (isset($_POST['hapus'])) {
    // Ambil data dari form
    $id = mysqli_real_escape_string($conn, $_POST['id']);

    $query = "DELETE FROM kode_promo WHERE id = '$id'";
    if (mysqli_query($conn, $query)) {
        $script = "
            Swal.fire({
                icon: 'success',
                title: 'Data Berhasil Dihapus!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    } else {
        $script = "
            Swal.fire({
                icon: 'error',
                title: 'Data Gagal Di-Hapus!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    }
}



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'link.php'; ?>
    <style>
        th,
        td {
            text-align: center !important;
        }
    </style>
    <script>
        $(document).ready(function() {

            $("#form").hide();

            $("#btn-show").click(function() {
                $("#form").show();
            })

            $("#btn-hide").click(function() {
                $("#form").hide();
            })

        });
    </script>
</head>

<body>


    <!-- ======== sidebar-nav start =========== -->
    <?php include 'sidebar.php'; ?>
    <!-- ======== sidebar-nav end =========== -->

    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">
        <!-- ========== header start ========== -->
        <header class="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-6">
                        <div class="header-left d-flex align-items-center">
                            <div class="menu-toggle-btn mr-20">
                                <button id="menu-toggle" class="main-btn primary-btn btn-hover">
                                    <i class="lni lni-chevron-left me-2"></i> Menu
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- ========== header end ========== -->

        <!-- ========== section start ========== -->
        <section class="section">
            <div class="container-fluid">
                <!-- ========== title-wrapper start ========== -->
                <div class="title-wrapper pt-30">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="title mb-30">
                                <h2>Pengelolaan Data Promo</h2>

                            </div>
                        </div>
                        <!-- end col -->
                        <div class="col-md-6">
                            <div class="breadcrumb-wrapper mb-30">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="#0">MIX Distro</a>
                                        </li>
                                        <li class="breadcrumb-item active" aria-current="page">
                                            Promo
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- ========== title-wrapper end ========== -->
                <a id="btn-show" class="btn btn-info text-white mb-3"><i class="fas fa-plus-square"></i> Tambah Data</a>


                <div class="form-elements-wrapper">
                    <div class="row">
                        <div class="col">
                            <!-- input style start -->
                            <form id="form" action="" method="post" enctype="multipart/form-data">
                                <div class="card-style mb-30">
                                    <p align="right">
                                        <a href="#" id="btn-hide" class="btn btn-close"></a>
                                    </p>
                                    <div class="input-style-1">
                                        <div class="input-style-1">
                                            <label>Kode</label>
                                            <input type="text" name="kode" required />
                                        </div>
                                    </div>
                                    <div class="input-style-1">
                                        <label>Masa Berlaku Hingga</label>
                                        <input type="date" name="masa_berlaku" required />
                                    </div>
                                    <div class="input-style-1">
                                        <label>% Promo (1 - 100)</label>
                                        <input type="number" name="jumlah_promo" required />
                                    </div>
                                    <button type="submit" name="submit" class="btn primary-btn btn-hover w-100 text-center">Tambah</button>
                                </div>
                            </form>
                        </div>
                        <!-- end card -->
                        <!-- ======= input style end ======= -->



                    </div>
                    <!-- end col -->
                </div>



                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Data Kode Promo</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="dataX" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Kode</th>
                                        <th>Masa Berlaku Hingga</th>
                                        <th>% Promo</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $stmt = $conn->prepare("SELECT * FROM kode_promo");
                                    $stmt->execute();
                                    $kode_promos = $stmt->get_result();
                                    ?>
                                    <?php $i = 1; ?>
                                    <?php foreach ($kode_promos as $data) : ?>
                                        <tr>
                                            <td><?= $i; ?></td>
                                            <td><?= htmlspecialchars($data['kode']); ?></td>
                                            <td><?= htmlspecialchars($data['masa_berlaku']); ?></td>
                                            <td><?= htmlspecialchars($data['jumlah_promo']); ?> %</td>
                                            <td>
                                                <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?= $data['id'] ?>">Edit</a>
                                                <br><br>
                                                <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#hapusModal<?= $data['id'] ?>">Hapus</a>
                                            </td>
                                        </tr>

                                        <!-- Modal Edit Kode Promo -->
                                        <div class="modal fade" id="editModal<?= $data['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="editModalLabel">Edit Data</h5>
                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="" method="POST">
                                                            <input type="hidden" name="id" value="<?= $data['id']; ?>">
                                                            <div class="form-group mb-3">
                                                                <label for="kode">Kode</label>
                                                                <input type="text" class="form-control" id="kode" name="kode" value="<?= $data['kode']; ?>" required>
                                                            </div>
                                                            <div class="form-group mb-3">
                                                                <label for="masa_berlaku">Masa Berlaku</label>
                                                                <input type="date" class="form-control" id="masa_berlaku" name="masa_berlaku" value="<?= $data['masa_berlaku']; ?>" required>
                                                            </div>
                                                            <div class="form-group mb-3">
                                                                <label for="jumlah_promo">% Promo (1 - 100)</label>
                                                                <input type="number" class="form-control" id="jumlah_promo" name="jumlah_promo" value="<?= $data['jumlah_promo']; ?>" required>
                                                            </div>
                                                            <button type="submit" name="edit" class="btn btn-primary w-100">Simpan</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Modal Hapus -->
                                        <div class="modal fade" id="hapusModal<?= $data['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="hapusModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="hapusModalLabel">Hapus Data Kode Promo</h5>
                                                        <button class="close" type="button" data-bs-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Apakah Anda yakin ingin menghapus data dengan ID Kode Promo: <b><?= htmlspecialchars($data['id']) ?></b>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Batal</button>
                                                        <form action="" method="post">
                                                            <input type="hidden" name="id" value="<?= $data['id'] ?>">
                                                            <button type="submit" name="hapus" class="btn btn-danger">Hapus</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <?php $i++; ?>
                                    <?php endforeach; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


            </div>
            <!-- end container -->
        </section>
        <!-- ========== section end ========== -->

        <!-- ========== footer start =========== -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 order-last order-md-first">
                        <div class="copyright text-center text-md-start">
                            <p class="text-sm">
                                Designed and Developed by
                                <a href="https://plainadmin.com" rel="nofollow" target="_blank">
                                    PlainAdmin
                                </a>
                            </p>
                        </div>
                    </div>
                    <!-- end col-->
                    <div class="col-md-6">
                        <div class="
                  terms
                  d-flex
                  justify-content-center justify-content-md-end
                ">
                            <a href="#0" class="text-sm">Term & Conditions</a>
                            <a href="#0" class="text-sm ml-15">Privacy & Policy</a>
                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </footer>
        <!-- ========== footer end =========== -->
    </main>
    <!-- ======== main-wrapper end =========== -->

    <!-- ========= All Javascript files linkup ======== -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/Chart.min.js"></script>
    <script src="assets/js/dynamic-pie-chart.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/fullcalendar.js"></script>
    <script src="assets/js/jvectormap.min.js"></script>
    <script src="assets/js/world-merc.js"></script>
    <script src="assets/js/polyfill.js"></script>
    <script src="assets/js/main.js"></script>

    <script src="ajax/index2.js"></script>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="js/demo/datatables-demo.js"></script>


    <script>
        <?php if (isset($script)) {
            echo $script;
        } ?>
    </script>

</body>

</html>