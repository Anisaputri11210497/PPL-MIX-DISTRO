<aside class="sidebar-nav-wrapper">
  <div class="navbar-logo">
    <a href="#">
      MIX Distro
    </a>
  </div>
  <nav class="sidebar-nav">
    <ul>
      <?php if (isset($_SESSION['super_userxxx'])) : ?>
        <li class="nav-item">
          <a href="index.php">
            <span class="icon">
              <i class="fas fa-home"></i>
            </span>
            <span class="text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a href="" class="dropdown-toggle" data-bs-toggle="dropdown">
            <span class="icon">
              <i class="fas fa-database"></i>
            </span>
            <span class="text">Data Master</span>
          </a>
          <ul class="dropdown-menu ms-2">
            <li class="nav-item">
              <a href="produk.php">
                <span class="icon">
                  <i class="fas fa-box"></i>
                </span>
                <span class="text">Data Produk</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="supplier.php">
                <span class="icon">
                  <i class="fas fa-users"></i>
                </span>
                <span class="text">Data Supplier</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="promo.php">
                <span class="icon">
                  <i class="fas fa-list"></i>
                </span>
                <span class="text">Data Promo</span>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="pesanan.php">
            <span class="icon">
              <i class="fas fa-file-invoice-dollar"></i>
            </span>
            <span class="text">Data Pesanan</span>
          </a>
        </li>
        <li class="nav-item">
          <a href="logout.php">
            <span class="icon">
              <i class="fas fa-sign-out-alt"></i>
            </span>
            <span class="text">Logout</span>
          </a>
        </li>
      <?php else : ?>
        <li class="nav-item">
          <a href="login.php">
            <span class="icon">
              <i class="fas fa-sign-in-alt"></i>
            </span>
            <span class="text">Login</span>
          </a>
        </li>
      <?php endif; ?>
      <span class="divider">
        <hr />
      </span>
    </ul>


</aside>
<div class="overlay"></div>