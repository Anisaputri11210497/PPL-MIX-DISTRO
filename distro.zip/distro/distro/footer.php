<?php

function addSubscriber($data)
{
	global $conn;

	$email = htmlspecialchars($data["email"]);

	mysqli_query($conn, "INSERT INTO subscriber VALUES('$email')");

	return mysqli_affected_rows($conn);
}

if (isset($_POST["subs"])) {

	if (addSubscriber($_POST) > 0) {
		$subscriberSuccess = true;
	} else {
		echo mysqli_error($conn);
	}
}

?>

<!-- NEWSLETTER -->
<div id="newsletter" class="section">
	<!-- container -->
	<div class="container">
		<!-- row -->
		<div class="row">
			<div class="col-md-12">
				<div class="newsletter">
					<p class="text-uppercase">Subscribe untuk menerima berita terbaru dari kami</p>
					<?php if (isset($subscriberSuccess)) : ?>
						<p><span class="badge bg-success text-white"><i class="fas fa-check-circle"></i>
								Berhasil Subscribe
							</span></p>
					<?php endif; ?>
					<form action="" method="post">
						<input class="input" type="email" name="email" placeholder="Alamat Email">
						<button class="newsletter-btn" type="submit" name="subs"><i class="fa fa-envelope"></i> Subscribe</button>
					</form>
					<ul class="newsletter-follow">
						<li>
							<a href="https://www.instagram.com/akarkelana.coffee/"><i class="fa fa-instagram"></i></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- /row -->
	</div>
	<!-- /container -->
</div>
<!-- /NEWSLETTER -->

<!-- FOOTER -->
<footer id="footer">
	<!-- top footer -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<div class="col-md-4 col-xs-6">
					<div class="footer">
						<h3 class="footer-title">MIX Distro</h3>
					</div>
				</div>

				<!-- <div class="col-md-4 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Kategori</h3>
								<ul class="footer-links">
									<li><a href="katalog/">Tenda dan Aksesoris</a></li>
									<li><a href="katalog/">Peralatan Masak</a></li>
									<li><a href="katalog/">Peralatan Lainnya</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-4 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Informasi</h3>
								<ul class="footer-links">
									<li><a href="sdk.php">Syarat dan Ketentuan</a></li>
								</ul>
							</div>
						</div> -->

			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /top footer -->

	<!-- bottom footer -->
	<div id="bottom-footer" class="section">
		<div class="container">
			<!-- row -->
			<div class="row">
				<div class="col-md-12 text-center">
					<span class="copyright">
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						MIX Distro &copy; <script>
							document.write(new Date().getFullYear());
						</script>
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
					</span>
				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /bottom footer -->
</footer>
<!-- /FOOTER -->