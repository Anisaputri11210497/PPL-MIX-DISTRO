<?php
// check_promo.php

require "functions.php";

// Cek apakah ada permintaan AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pastikan kode promo yang diterima tidak kosong
    if (!empty($_POST['kode_promo'])) {
        $kodePromo = $_POST['kode_promo'];

        // Query untuk memeriksa keberadaan dan masa berlaku kode promo
        $query = mysqli_query($conn, "SELECT * FROM kode_promo WHERE kode = '$kodePromo'");

        if (mysqli_num_rows($query) > 0) {
            $promo = mysqli_fetch_assoc($query);

            // Periksa masa berlaku kode promo
            $expired = strtotime($promo['masa_berlaku']) < time();

            // Kode promo ditemukan, kirim respons dalam format JSON
            $response = [
                'exists' => true,
                'expired' => $expired
            ];
        } else {
            // Kode promo tidak ditemukan
            $response = [
                'exists' => false
            ];
        }

        echo json_encode($response);
    }
}
