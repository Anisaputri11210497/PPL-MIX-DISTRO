<?php
session_start();

include '../functions.php';

if (!isset($_SESSION['user_akusara'])) {
    header("Location: ../");
    exit;
}

$getKodePesanan = $_GET['kode_pesanan'];
$whatsapp = $_SESSION['whatsapp'];

?>

<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<style>
    * {
        font-size: 0.9rem;
    }
</style>

<body>


    <center>
        <h3>MIX Distro</h3>
        <br>
        <!-- <p>Jl. Brig Jend. Hasan Basri Jl. Kayu Tangi 2 Jalur 3 No.77, Pangeran, Kec. Banjarmasin Utara, Kota Banjarmasin, Kalimantan Selatan 70124 <br>087861919270</p> -->
    </center>
    <div class="col">
        <div class="order-summary">
            <?php mysqli_query($conn, "SET sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''))");
            $pesanan = mysqli_query($conn, "SELECT * FROM pesanan WHERE whatsapp = '$whatsapp' AND status != 'Menunggu Pembayaran' AND kode_pesanan = '$getKodePesanan' GROUP BY kode_pesanan");
            ?>
            <?php error_reporting(0); ?>
            <?php foreach ($pesanan as $data) : ?>
                <div class="my-2 ">
                    <div style="border-bottom: 2px dotted black;">
                        <?php if (isset($data['waktu'])) : ?>
                            <p style="font-size: 0.8rem;">Tanggal: <?= date('d F, Y. H:i:s', strtotime($data['waktu'])); ?></p>

                            <p style="font-size: 0.8rem;">Kode Pesanan: <?= $getKodePesanan; ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="order-col">
                        <div><strong>PRODUCT</strong></div>
                        <div><strong>SUBTOTAL</strong></div>
                    </div>
                    <?php $total_harga = 0; ?>
                    <?php $total_diskon = 0; ?>
                    <div class="order-products">
                        <?php $kode_pesanan = $data['kode_pesanan']; ?>
                        <?php $detail_pesanan = mysqli_query($conn, "SELECT * FROM pesanan WHERE whatsapp = '$whatsapp' AND status != 'Menunggu Pembayaran' AND kode_pesanan = '$kode_pesanan' "); ?>
                        <?php foreach ($detail_pesanan as $detail) : ?>
                            <?php $kode = $detail['kode_pesanan']; ?>
                            <div class="order-col">
                                <div>
                                    <small>
                                        <?php $idp = $detail['id_produk']; ?>
                                        <?php $produk = query("SELECT * FROM produk WHERE id = $idp")[0]; ?>
                                        <?= $produk['nama']; ?> &nbsp;
                                        X <?= $detail['jumlah']; ?>
                                    </small>
                                </div>
                                <div>
                                    <small>
                                        <?php $harga_fix = $detail['harga'] * $detail['jumlah']; ?>
                                        <span>Rp<?= number_format($harga_fix, 0, ',', '.'); ?></span>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <?php if ($detail['id_kode_promo'] != NULL) : ?>
                            <div class="order-col">
                                <div class="text-success fw-bold">Diskon Kode Promo</div>
                                <?php
                                $id_kode_promo = $detail['id_kode_promo'];
                                $kode_promo = query("SELECT * FROM kode_promo WHERE id = $id_kode_promo")[0];
                                $diskon_promo = $kode_promo['jumlah_promo'];

                                ?>
                                <div class="text-success fw-bold">
                                    <strong><?= $diskon_promo; ?>%</strong>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="order-col">
                            <div class="text-success fw-bold">Total Belanja</div>
                            <?php
                            $total = query("SELECT SUM(jumlah * harga) as biaya FROM pesanan WHERE whatsapp = '$whatsapp' AND kode_pesanan = '$kode' AND status != 'Menunggu Pembayaran'")[0];
                            $total_diskon_promo = ($total['biaya'] * $diskon_promo) / 100;
                            if (!isset($total['biaya'])) {
                                $total['biaya'] = 0;
                            }
                            ?>
                            <?php if ($detail['id_kode_promo'] != NULL) : ?>
                                <div class="text-success fw-bold">
                                    <?php $totalFix = $total['biaya'] - $total_diskon_promo; ?>
                                    <strong>Rp<?= number_format($totalFix, 0, ',', '.'); ?></strong>
                                </div>
                            <?php else : ?>
                                <div class="text-success fw-bold">
                                    <strong>Rp<?= number_format($total['biaya'], 0, ',', '.'); ?></strong>
                                </div>
                            <?php endif; ?>

                        </div>

                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>


    <script>
        window.print();
    </script>

</body>

</html>